﻿<?php

phpinfo();

?>