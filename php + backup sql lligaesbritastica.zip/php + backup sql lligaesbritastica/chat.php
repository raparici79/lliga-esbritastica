﻿<?php
/************************************************
*	File: 	chat.php					*
*	Desc: 	chat.			*
*	Author:	Rubén Aparici 						*
************************************************/

//$self = $_SERVER['PHP_SELF']; //Obtenemos la página en la que nos encontramos
//header("refresh:50; url=$self"); //Refrescamos cada 5 segundos

?>
<html>
<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="../templates/rhuk_solarflare_ii/css/template_css.css" rel="stylesheet" type="text/css"/>


</head>
<body>
<!--
<center><embed src="http://www.xatech.com/web_gear/chat/chat.swf" quality="high" bgcolor="#000000" width="100%" height="420" name="chat" FlashVars="id=118050833&gn=LligaEsbritstica" align="middle" allowScriptAccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://xat.com/update_flash.shtml" /></center>
<br>
Quin preferiu? Es que en el de dalt de tot pareix que en el temps se borren els missatges..
<br>
<!--
<object width="350" height="450" id="obj_1287579366687"><param name="movie" value="http://lligaesbritastica.chatango.com/group"/><param name="AllowScriptAccess" VALUE="always"/><param name="AllowNetworking" VALUE="all"/><param name="AllowFullScreen" VALUE="true"/><param name="flashvars" value="cid=1287579366687&a=FF9933&b=100&c=FFFFFF&d=FFFFFF&g=333333&j=333333&k=FF6600&l=FF6600&m=FF6600&n=FFFFFF&p=12&s=1&t=0&w=0"/><embed id="emb_1287579366687" src="http://lligaesbritastica.chatango.com/group" width="350" height="450" allowScriptAccess="always" allowNetworking="all" type="application/x-shockwave-flash" allowFullScreen="true" flashvars="cid=1287579366687&a=FF9933&b=100&c=FFFFFF&d=FFFFFF&g=333333&j=333333&k=FF6600&l=FF6600&m=FF6600&n=FFFFFF&p=12&s=1&t=0&w=0"></embed></object><br>[ <a href="http://lligaesbritastica.chatango.com/clonegroup?ts=1287579366687">Copy this</a> | <a href="http://chatango.com/creategroup?ts=1287579366687">Start New</a> | <a href="http://lligaesbritastica.chatango.com">Full Size</a> ]
-->

<!-- BEGIN CBOX - www.cbox.ws - v001 
<div id="cboxdiv" style="text-align: center; line-height: 0">
<div><iframe frameborder="0" width="200" height="305" src="http://www2.cbox.ws/box/?boxid=2096026&amp;boxtag=&amp;sec=main" marginheight="2" marginwidth="2" scrolling="auto" allowtransparency="yes" name="cboxmain" style="border:#FFFFFF 1px solid;" id="cboxmain"></iframe></div>
<div><iframe frameborder="0" width="200" height="75" src="http://www2.cbox.ws/box/?boxid=2096026&amp;boxtag=&amp;sec=form" marginheight="2" marginwidth="2" scrolling="no" allowtransparency="yes" name="cboxform" style="border:#FFFFFF 1px solid;border-top:0px" id="cboxform"></iframe></div>
</div>
END CBOX -->
<!-- BEGIN CBOX - www.cbox.ws - v001 -->
<div id="cboxdiv" style="text-align: center; line-height: 0">
<div><iframe frameborder="0" width="100%" height="305" src="http://www2.cbox.ws/box/?boxid=2096026&amp;boxtag=&amp;sec=main" marginheight="2" marginwidth="2" scrolling="auto" allowtransparency="yes" name="cboxmain" style="border:#FFFFFF 1px solid;" id="cboxmain"></iframe></div>
<div><iframe frameborder="0" width="100%" height="75" src="http://www2.cbox.ws/box/?boxid=2096026&amp;boxtag=&amp;sec=form" marginheight="2" marginwidth="2" scrolling="no" allowtransparency="yes" name="cboxform" style="border:#FFFFFF 1px solid;border-top:0px" id="cboxform"></iframe></div>
</div>
<!-- END CBOX -->
</body>
</html>
