﻿<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="es" xml:lang="es" >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!--<link href="estil.css" rel="stylesheet" type="text/css"/> -->
<link type="text/css" href="estil.css?<?php echo date('Y-m-d H:i:s'); ?>" rel="stylesheet" />
</head>
<body>
<table width="100%"><tr>
<td><a href="fer_equip2.php">Alineació</a></td>
<td><a href="fer_equip.php">Gestió equip</a></td>
<td><a href="classificacio.php">classificació</a></td>
<td><a href="copa.php">Copa</a></td>
<td><a href="estadistiques.php">el que l'ull no veu</a></td>
<td><a href="llistat_jugadors.php">jugadors</a></td>
<td><a href="rivals.php">rivals</a></td>
<td><a href="admin.html">Administradors</a></td>
</tr>
</table>
<table width="100%"><tr>
<td>SI NO TE FUNCIONEN ELS LINKS,</td>
</tr>
</table>
</table>
<table width="100%"><tr>
<td>PROVA A COPIAR Y PEGAR ESTA DIRECCIO EN EL NAVEGADOR:</td>
</tr>
</table>
<table width="100%"><tr>
<td>http://lligaesbritastica.es</td>
</tr>
</table>
<table width="100%"><tr>
<td>I SI TAMPOC, PROVA ESTA:</td>
</tr>
</table>
<table width="100%"><tr>
<td>https://lligaesbritastica.es</td>
</tr>
</table>
</body>

